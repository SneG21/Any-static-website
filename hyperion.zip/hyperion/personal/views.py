from django.shortcuts import render

# Create your views here.

from django.shortcuts import render

def about(request):
    return render(request, 'personal/about.html')

def index(request):
    return render(request, 'personal/index.html')

def contact(request):
    return render(request, 'personal/contact.html')